# Demo_DAWGI_HBM
Age-metallicity inference of a simple stellar population.
